SOAR Themes Bundle
==================

Contents:
  README.txt
  aphrodite.palette
  ares.palette
  athena.palette
  ember.palette
  icons
  install.sh
  neon.palette
  overrides.css
  poseidon.palette
  soar-add-theme.sh

Install on the SOAR appliance:
  scp soar-themes-bundle.tar.gz csadmin@<appliance>:/tmp/
  ssh csadmin@<appliance>
  cd /tmp && tar xzf soar-themes-bundle.tar.gz && cd soar-themes-bundle
  sudo ./install.sh

Then in the browser console (or DevTools -> Application -> Clear site data):
  Object.keys(localStorage).filter(k=>k.includes('themes'))
    .forEach(k=>localStorage.removeItem(k));
  location.reload();

Switch theme via Settings -> System Configuration -> Theme.

Re-run install.sh after SOAR upgrades — upgrades rewrite themes.json and
strip your entries. The CSS files survive.
