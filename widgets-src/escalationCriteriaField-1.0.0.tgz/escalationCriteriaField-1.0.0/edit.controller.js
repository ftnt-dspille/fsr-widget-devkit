/* Copyright start
  Copyright (C) 2008 - 2026 Fortinet Inc.
  All rights reserved.
  FORTINET CONFIDENTIAL & FORTINET PROPRIETARY SOURCE CODE
  Copyright end */
'use strict';
(function () {
  angular
    .module('cybersponse')
    .controller('editEscalationCriteriaField100Ctrl', editEscalationCriteriaField100Ctrl);

  editEscalationCriteriaField100Ctrl.$inject = ['$scope', '$uibModalInstance', 'config', 'widgetUtilityService', '$timeout', 'appModulesService', 'modelMetadatasService'];

  function editEscalationCriteriaField100Ctrl($scope, $uibModalInstance, config, widgetUtilityService, $timeout, appModulesService, modelMetadatasService) {
    $scope.cancel = cancel;
    $scope.save = save;
    $scope.config = config;

    function _handleTranslations() {
      let widgetNameVersion = widgetUtilityService.getWidgetNameVersion($scope.$resolve.widget, $scope.$resolve.widgetBasePath);

      if (widgetNameVersion) {
        widgetUtilityService.checkTranslationMode(widgetNameVersion).then(function () {
          $scope.viewWidgetVars = {
            EDIT_VIEW_TITLE: widgetUtilityService.translate('escalationCriteriaField.EDIT_VIEW_TITLE'),
            EDIT_VIEW_DESC: widgetUtilityService.translate('escalationCriteriaField.EDIT_VIEW_DESC'),
            SAVE_BTN: widgetUtilityService.translate('escalationCriteriaField.SAVE_BTN'),
            CLOSE_BTN: widgetUtilityService.translate('escalationCriteriaField.CLOSE_BTN'),
          };
        });
      } else {
        $timeout(function () {
          $scope.cancel();
        });
      }

      appModulesService.load().then(function (modules) {
        $scope.modules = modules;
        angular.forEach($scope.modules, function (module) {
          var metadata = modelMetadatasService.getModuleNameByType([module.type], false);
          module.displayName = metadata.length > 0 ? metadata[0].name : module.name;
        });

      });
    }

    function init() {
      // To handle backward compatibility for widget
      _handleTranslations();
    }

    init();

    function cancel() {
      $uibModalInstance.dismiss('cancel');
    }

    function save() {
      $uibModalInstance.close($scope.config);
    }

  }
})();
