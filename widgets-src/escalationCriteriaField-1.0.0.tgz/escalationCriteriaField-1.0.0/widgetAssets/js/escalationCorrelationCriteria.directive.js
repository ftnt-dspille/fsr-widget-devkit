/* Copyright start
  Copyright (C) 2008 - 2026 Fortinet Inc.
  All rights reserved.
  FORTINET CONFIDENTIAL & FORTINET PROPRIETARY SOURCE CODE
  Copyright end */
  'use strict';

  (function () {
  
    angular
      .module('cybersponse')
      .directive('escalationCorrelationCriteria', escalationCorrelationCriteria)
      .filter('filterObject', filterObject);
  
    escalationCorrelationCriteria.$inject = ['CRUD_HUB'];
    function escalationCorrelationCriteria(CRUD_HUB) {
  
      return {
        restrict: 'A',
        require: 'ngModel',
        scope: {
          value: '=ngModel',
          fields: '=',
          disabled: '=?',
          removeGroup: '=?'
        },
        templateUrl: 'widgets/installed/escalationCriteriaField-1.0.0/widgetAssets/html/escalationCorrelationCriteria.html',
        link: function (scope) {
  
          scope.logicals = CRUD_HUB.LOGICALS_ENGLISH_NEW;
  
          function init() {
  
            if (!scope.value) {
              scope.value = {
                logic: 'AND',
                filters: []
              };
            }
  
            scope.query = scope.value;
  
            buildFields();
          }
  
          function buildFields() {
  
            scope.primaryFields = {};
  
            angular.forEach(scope.fields, function (field) {
              if (field.type !== 'manyToMany') {
                scope.primaryFields[field.name] = field;
              }
            });
  
          }
  
          scope.searchField = function (event) {
            event.preventDefault();
            event.stopPropagation();
          };
  
          scope.addCondition = function () {
  
            scope.query.filters.push({
              alertField: '',
              incidentField: ''
            });
  
          };
  
          scope.removeCondition = function (index) {
            scope.query.filters.splice(index, 1);
          };
  
          scope.addGroup = function () {
  
            scope.query.filters.push({
              logic: 'AND',
              filters: []
            });
  
          };
  
          // scope.removeGroup = function (group) {
  
          //   scope.query.filters = scope.query.filters.filter(function (f) {
          //     return f !== group;
          //   });
  
          // };
  
          scope._removeGroup = function (group) {
  
            var newFilters = [];
  
            angular.forEach(scope.query.filters, function (f) {
              if (f.$$hashKey !== group.$$hashKey) {
                newFilters.push(f);
              }
            });
  
            scope.query.filters = newFilters;
  
            scope.setValue();
  
          };
  
          scope.setValue = function () {
            scope.value = angular.copy(scope.query);
          };
  
          init();
  
        }
      };
  
    }
  
    function filterObject() {
  
      return function (fields, scope) {
  
        if (scope.params && scope.params.srchBox) {
  
          var objs = {};
  
          angular.forEach(fields, function (field, key) {
  
            if (field.title &&
                field.title.toLowerCase()
                .indexOf(scope.params.srchBox.toLowerCase()) >= 0) {
  
              objs[key] = field;
  
            }
  
          });
  
          return objs;
  
        }
  
        return fields;
  
      };
  
    }
  
  })();