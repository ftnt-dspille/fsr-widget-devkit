/* Copyright start
  Copyright (C) 2008 - 2026 Fortinet Inc.
  All rights reserved.
  FORTINET CONFIDENTIAL & FORTINET PROPRIETARY SOURCE CODE
  Copyright end */
  'use strict';
  (function () {
    angular
      .module('cybersponse')
      .controller('escalationCriteriaField100Ctrl', escalationCriteriaField100Ctrl);
  
    escalationCriteriaField100Ctrl.$inject = ['$scope', 'widgetUtilityService', 'Entity', 'FormEntityService', '$state', '_', '$rootScope', 'Modules', 'API', '$resource', 'CommonUtils'];
  
    function escalationCriteriaField100Ctrl($scope, widgetUtilityService, Entity, FormEntityService, $state, _, $rootScope, Modules, API, $resource, CommonUtils) {
  
      $scope.filterValue;
      $scope.selectedGoupByFields = [];
      $scope.groupByTitleFields = [];
      $scope.discardFilters = ["neq", "notlike", "like_pattern", "notlike_pattern", "isnull"]
      $scope.viewPanelState = $state.params.viewPanelState;
      var notRequiredFields = ['datetime', 'checkbox', 'file', 'object', 'json', 'phone', 'multiselect', 'decimal', 'richtext']
  
      function _handleTranslations() {
        widgetUtilityService.checkTranslationMode($scope.$parent.model.type).then(function () {
          $scope.viewWidgetVars = {
            // Create your translating static string variables here
            "RULE_CONFIG": widgetUtilityService.translate('escalationCriteriaField.RULE_CONFIG'),
            "ESCALATION_RULE_COND": widgetUtilityService.translate('escalationCriteriaField.ESCALATION_RULE_COND'),
            "ESCALATION_RULE_COND_DESC": widgetUtilityService.translate('escalationCriteriaField.ESCALATION_RULE_COND_DESC'),
            "GROUP_BY": widgetUtilityService.translate('escalationCriteriaField.GROUP_BY'),
            "GROUP_BY_DESC": widgetUtilityService.translate('escalationCriteriaField.GROUP_BY_DESC'),
            "GROUP_CONDITION": widgetUtilityService.translate('escalationCriteriaField.GROUP_CONDITION'),
            "ALL": widgetUtilityService.translate('escalationCriteriaField.ALL'),
            "ANY": widgetUtilityService.translate('escalationCriteriaField.ANY')
          };
        });
      }
  
      function init() {
        // To handle backward compatibility for widget
        _handleTranslations();
        $scope.escalationEntity = FormEntityService.get();
        loadResourceFields();
      }
  
      function loadResourceFields() {
        if ($scope.config.module) {
          var entity = new Entity($scope.config.module);
          var resourceFields = {};
          entity.loadFields().then(function () {
            angular.forEach(entity.getFormFields(), function (field, key) {
              if (!notRequiredFields.includes(field.type)) {
                resourceFields[key] = field;
              }
            });
            $scope.resourceFields = resourceFields;
            $scope.groupByFields = _.map($scope.resourceFields, function (field) {
              return field.title;
            });
            let goupByFieldValue = JSON.parse(($scope.escalationEntity.fields.groupBy.value).replace(/'/g, '"'));
            $scope.groupByTitleFields = _.map(goupByFieldValue, function (field) {
              return $scope.resourceFields[field].title;
            });
            $scope.groupByOperator = $scope.escalationEntity.groupByOperator || 'OR';
            _updateGroupByTooltip();
          });
        }
      }
  
      $scope.updateGroupByFields = function (title, isSelected) {
        if ($scope.selectedGoupByFields.length === 0 && !CommonUtils.isUndefined($scope.escalationEntity.id)) {
          $scope.selectedGoupByFields = JSON.parse(($scope.escalationEntity.fields.groupBy.value).replace(/'/g, '"'));
        }
        var field = _.find($scope.resourceFields, function (obj) {
          return obj.title === title;
        });
        if (!field)
          return;
        if (isSelected) {
          if (!_.includes($scope.selectedGoupByFields, field.name)) {
            $scope.selectedGoupByFields.push(field.name);
          }
        } else {
          $scope.selectedGoupByFields = $scope.selectedGoupByFields.filter(item => item !== field.name);
        }
        if (CommonUtils.isUndefined($scope.escalationEntity.id)) {
          $scope.escalationEntity.fields.groupBy.value = JSON.stringify($scope.selectedGoupByFields)
        }
        else {
          _updateGroupByField($scope.selectedGoupByFields).then(function () {
            $rootScope.$broadcast('field:updated', ['groupBy']);
            $rootScope.$broadcast('viewPanel:reloadFields', ['groupBy']);
          })
            .catch(function (err) {
              console.error('API call failed', err);
            });
        }
      };
  
      function _updateGroupByField(groupByValue) {
        const payload = {
          groupBy: JSON.stringify(groupByValue)
        };
        const endpoint = API.BASE + $scope.escalationEntity.module + '/' + $scope.escalationEntity.id;
        return $resource(
          endpoint,
          null,
          {
            update: { method: 'PUT' },
          },
          { stripTrailingSlashes: false }
        ).update(payload).$promise;
      }
  
      init();
    }
  })();
  